
Tab["Favorite"] = "Favorite"
Tab["Sell"] = "Sell"
Tab["All"] = "All"

Tab["Meds"] = "Meds"
Tab["Tools"] = "Tools"
Tab["Materials"] = "Materials"
Tab["Ammo"] = "Ammo"
Tab["Weapons"] = "Weapons"
Tab["Vehicles"] = "Vehicles"
Tab["Automotive"] = "Automotive"
Tab["Eden"] = "Eden"

Shop.Tabs = {}
Shop.Items= {}


Shop.Tabs[Tab.Favorite] = getText("IGUI_Tab_Favorite")
Shop.Tabs[Tab.Sell] = getText("IGUI_Tab_Sell")
Shop.Tabs[Tab.All] = getText("IGUI_Tab_All")

Shop.Tabs[Tab.Meds] = getText("IGUI_Tab_Meds")
Shop.Tabs[Tab.Tools] = getText("IGUI_Tab_Tools")
Shop.Tabs[Tab.Materials] = getText("IGUI_Tab_Materials")
Shop.Tabs[Tab.Ammo] = getText("IGUI_Tab_Ammo")
Shop.Tabs[Tab.Weapons] = getText("IGUI_Tab_Weapons")
Shop.Tabs[Tab.Vehicles] = getText("IGUI_Tab_Vehicles")
Shop.Tabs[Tab.Automotive] = getText("IGUI_Tab_Automotive")
Shop.Tabs[Tab.Eden] = getText("IGUI_Tab_Eden")

