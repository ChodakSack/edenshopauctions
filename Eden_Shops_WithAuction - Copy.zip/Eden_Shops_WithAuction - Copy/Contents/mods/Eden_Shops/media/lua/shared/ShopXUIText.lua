UIText["ShopUITitle"] = "Eden Shops"

--For more translation stuff take a look in the main mod nshop